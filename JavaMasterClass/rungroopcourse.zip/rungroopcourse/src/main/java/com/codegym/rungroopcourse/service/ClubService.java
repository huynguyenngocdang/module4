package com.codegym.rungroopcourse.service;

import com.codegym.rungroopcourse.dto.ClubDto;

import java.util.List;

public interface ClubService {
    List<ClubDto> findAllClub();
}
