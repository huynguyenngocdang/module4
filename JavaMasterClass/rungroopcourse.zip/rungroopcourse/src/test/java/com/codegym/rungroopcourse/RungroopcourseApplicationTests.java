package com.codegym.rungroopcourse;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class RungroopcourseApplicationTests {

	@Test
	void contextLoads() {
	}

}
